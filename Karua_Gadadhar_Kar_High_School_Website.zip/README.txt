KARUA GADADHAR KAR HIGH SCHOOL WEBSITE
========================================
Files:
- index.html  : website content
- style.css   : design and responsive layout
- script.js   : mobile menu and footer year

Open index.html in a browser to view the website.

Before publishing:
1. Replace placeholder contact details with official information.
2. Add real school photographs to the gallery.
3. Add verified notices, staff, achievements and academic details.
4. Connect the enquiry form to an email/form service if needed.
